export class InputDto {
    id: number;
    name: string;
    categoryName: string;
    typeId: number;
}
