export class ProductDto {
    id: number;
    name: string;
    categoryName: string;
}
