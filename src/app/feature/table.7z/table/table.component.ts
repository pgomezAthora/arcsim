import { Component, OnInit } from '@angular/core';
import { DemoTableService } from './demo-table.service';
import {
    ITableData,
    ITableHeader,
    ProductHeader,
    RowTable
} from './interfaces/table-header.interface';

export interface PeriodicElement {
    name: string;
    position: number;
    weight: number;
    symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
    { position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
    { position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
    { position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
    { position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
    { position: 5, name: 'Boron', weight: 10.811, symbol: 'B' },
    { position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C' },
    { position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N' },
    { position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O' },
    { position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F' },
    { position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne' }
];

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
    selector: 'table-example',
    templateUrl: './table.component.html',
    styleUrls: ['./table.component.scss']
})
export class TableBasicComponent implements OnInit {
    tableHeaders: ITableHeader[] = [];

    testeo: string[] = [];
    dataSource: ITableData[] = [];
    displayedColumns: string[] = [];
    displayNoStickyColumns: string[] = [];
    stickyColumns: string[] = [];

    constructor(private demoTableService: DemoTableService) {}
    ngOnInit(): void {
        const d: ITableHeader = {
            category: 'test',
            hide: false,
            id: 1,
            colspan: 0,
            products: [
                {
                    id: 1,
                    name: 'produ 1',
                    col: 'produ_1'
                },
                {
                    id: 2,
                    name: 'produ 2',
                    col: 'produ_2'
                }
            ]
        };
        d.colspan = d.products.length;
        this.tableHeaders.push(d);
        const r: ITableHeader = {
            category: 'testDummy',
            hide: false,
            id: 2,
            colspan: 0,
            products: [
                {
                    id: 3,
                    name: 'produ 3',
                    col: 'produ_3'
                },
                {
                    id: 4,
                    name: 'produ 4',
                    col: 'produ_4'
                }
            ]
        };
        r.colspan = r.products.length;
        this.tableHeaders.push(r);

        console.log(this.tableHeaders);

        this.getDummyData();

        console.log(this.dataSource);
        this.stickyColumns = ['input_category', 'input_name'];
        this.testeo = ['header-row-first-group', 'test', 'testDummy'];
        this.generateDisplayedColumns();

        console.log(this.displayedColumns);
        // const data = this.demoTableService.getProduct();

        // data.map((x) => {
        //     const item = this.tableHeaders.find((y) => y.category === x.categoryName);
        //     if (item) {
        //         const d: ProductHeader = {
        //             id: x.id,
        //             name: x.name
        //         };
        //         item.products.push(d);
        //     } else {
        //         const d: ITableHeader = {
        //             id: x.id,
        //             hide: false,
        //             category: x.categoryName,
        //             products: []
        //         };
        //         this.tableHeaders.push(d);
        //     }
        // });

        // console.log(this.tableHeaders);
        // this.testeo = this.tableHeaders
        //     .filter((x) => x.hide === false)
        //     .map((x) => x.category);

        // console.log(this.testeo);

        // const ters: string[] = [];
        // // debugger;
        // for (const item of this.tableHeaders) {
        //     const ddd = item.products.map((x) => x.name);
        //     ters.concat(ddd);
        // }

        // const tttt = this.tableHeaders.map((x) => x.products.map((y) => y.name));
        // const result = tttt.reduce((accumulator, value) => accumulator.concat(value), []);
        // console.log(result);

        // this.createDummyData();
        // console.log(this.dataSource);
        // this.displayedColumns = result;
    }

    original: string[] = ['position', 'name', 'weight', 'symbol'];
    cambio = ['position', 'symbol'];
    mostrar = true;
    // displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
    // dataSource: string[][] = []; // = ELEMENT_DATA;
    // dataSource = ELEMENT_DATA;

    // toggle() {
    //     console.log('test');
    //     if (this.mostrar) {
    //         this.displayedColumns = this.cambio;
    //     } else {
    //         this.displayedColumns = this.original;
    //     }

    //     this.mostrar = !this.mostrar;
    // }

    toggle(id: number) {
        const item = this.tableHeaders.find((x) => x.id === id);
        if (!item) {
            return;
        }

        if (item.hide) {
            item.colspan = item.products.length;
        } else {
            item.colspan = 1;
        }

        item.hide = !item.hide;
        this.generateDisplayedColumns();
    }

    generateDisplayedColumns() {
        const columns = [];
        for (const item of this.tableHeaders) {
            if (item.hide) {
                columns.push(`${item.category}_empty`);
            } else {
                columns.push(...item.products.map((y) => y.col));
            }
        }

        this.displayNoStickyColumns = columns;
        this.displayedColumns = [...this.stickyColumns, ...this.displayNoStickyColumns];
    }

    // createDummyData() {
    //     const data = this.demoTableService.getInput();

    //     for (const inputData of data) {
    //         const d: string[] = [];
    //         for (const category of this.tableHeaders) {
    //             for (const product of category.products) {
    //                 d.push(inputData.name + product.name + 'dummy');
    //             }
    //         }
    //         this.dataSource.push(d);
    //     }
    // }

    getDummyData() {
        const element1: ITableData = {
            hide: false,
            group: 'category_1',
            category: 'category 1',
            agrupar: true
        };
        element1.input_category = 'category 1';
        element1.input_name = 'input 1';
        element1.produ_1 = 'Produ 1 Input 1';
        element1.produ_2 = 'Produ 2 Input 1';
        element1.test_empty = '';
        element1.produ_3 = 'Produ 3 Input 1';
        element1.produ_4 = 'Produ 4 Input 1';
        element1.testDummy_empty = 'testDummy empty1';

        const element2: ITableData = {
            hide: false,
            group: 'category_1',
            category: 'category 1',
            agrupar: false
        };

        element2.input_category = 'category 1';
        element2.input_name = 'input 2';
        element2.produ_1 = 'Produ 1 Input 2';
        element2.produ_2 = 'Produ 2 Input 2';
        element2.test_empty = '';
        element2.produ_3 = 'Produ 3 Input 1';
        element2.produ_4 = 'Produ 4 Input 1';
        element2.testDummy_empty = 'testDummy empty1';

        const element3: ITableData = {
            hide: false,
            group: 'category_2',
            category: 'category 2',
            agrupar: true
        };
        element3.input_category = 'category 2';
        element3.input_name = 'input 3';
        element3.produ_1 = 'Produ 1 Input 3';
        element3.produ_2 = 'Produ 2 Input 3';
        element3.test_empty = '';
        element3.produ_3 = 'Produ 3 Input 3';
        element3.produ_4 = 'Produ 4 Input 3';
        element3.testDummy_empty = 'testDummy empty1';

        const element4: ITableData = {
            hide: false,
            group: 'category_2',
            category: 'category 2',
            agrupar: false
        };

        element4.input_category = 'category 2';
        element4.input_name = 'input 4';
        element4.produ_1 = 'Produ 1 Input 4';
        element4.produ_2 = 'Produ 2 Input 4';
        element4.test_empty = '';
        element4.produ_3 = 'Produ 3 Input 4';
        element4.produ_4 = 'Produ 4 Input 4';
        element4.testDummy_empty = 'testDummy empty1';

        this.dataSource.push(element1);
        this.dataSource.push(element2);
        this.dataSource.push(element3);
        this.dataSource.push(element4);
    }
}

/**  Copyright 2018 Google Inc. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */
