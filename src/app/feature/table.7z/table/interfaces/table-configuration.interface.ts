export interface tableConfig {}
