import { IColumnDefinition } from './table-data.interface';

export interface ProductHeader {
    id: number;
    name: string;
    col: string;
}

export interface ITableHeader {
    id: number;
    category: string;
    hide: boolean;
    colspan: number;
    products: ProductHeader[];
}

export interface RowTable {
    input: string;
}

export class TableHeader implements ITableHeader {
    id: number;
    category: string;
    hide: boolean;
    colspan: number;
    products: ProductHeader[];
    constructor() {}
}

export class ITableData {
    hide: boolean;
    group: string;
    agrupar: boolean;
    [key: string]: IColumnDefinition | string | boolean;
}
